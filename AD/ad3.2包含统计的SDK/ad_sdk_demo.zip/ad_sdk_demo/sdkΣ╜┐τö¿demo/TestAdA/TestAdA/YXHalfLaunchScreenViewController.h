//
//  YXHalfLaunchScreenViewController.h
//  LunchAd
//
//  Created by shuai on 2018/10/23.
//  Copyright © 2018年 YX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YXHalfLaunchScreenViewController : UIViewController

@end
