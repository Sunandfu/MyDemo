//
//  ViewController.h
//  WebViewDemo
//
//  Created by lurich on 2019/4/12.
//  Copyright © 2019 lurich. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HalfViewController : UIViewController

@property (nonatomic, assign) BOOL isShowAll;

@end

