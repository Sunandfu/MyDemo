//
//  ViewController.m
//  TestAdA
//
//  Created by shuai on 2018/3/24.
//  Copyright © 2018年 YX. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"viewDidLoad");
    self.view.backgroundColor = [UIColor cyanColor];
    
 
 
    
    // Do any additional setup after loading the view, typically from a nib.
}


@end
