//
//  BannerViewController.h
//  GDTTestDemo
//
//  Created by 高超 on 13-11-1.
//  Copyright (c) 2013年 高超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BannerViewController : UIViewController

@end
