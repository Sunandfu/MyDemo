//
//  GDTNativeViewController.h
//  GDTMobApp
//
//  Created by michaelxing on 2016/11/2.
//  Copyright © 2016年 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NativeViewController : UIViewController

@end
