//
//  SplashViewContronller.h
//  GDTMobApp
//
//  Created by GaoChao on 15/8/21.
//  Copyright © 2015年 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SplashViewController : UIViewController

@end
