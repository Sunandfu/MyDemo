//
//  UnifiedNativeAdViewController.h
//  GDTMobApp
//
//  Created by nimomeng on 2018/10/12.
//  Copyright © 2018 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UnifiedNativeAdViewController : UIViewController

@end
