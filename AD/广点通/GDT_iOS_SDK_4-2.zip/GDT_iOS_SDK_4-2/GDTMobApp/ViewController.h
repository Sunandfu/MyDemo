//
//  ViewController.h
//  GDTTestDemo
//
//  Created by 高超 on 13-10-31.
//  Copyright (c) 2013年 高超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, strong) NSMutableArray *demoArray;
@property (nonatomic, strong) NSMutableDictionary *demoDict;

@end
