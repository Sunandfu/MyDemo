//
//  BaiduMobAdPrerollNativeViewController.h
//  BaiduMobAdDemoApp
//
//  Created by lishan04 on 16/11/21.
//  Copyright © 2016年 Baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaiduMobAdPrerollNativeViewController : UIViewController

@end
