//
//  BaiduMobAdPrerollViewController.h
//  XAdSDKDevSample
//
//  Created by lishan04 on 16/5/5.
//  Copyright © 2016年 Baidu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaiduMobAdSDK/BaiduMobAdPrerollDelegate.h"
#import "BaiduMobAdSDK/BaiduMobAdPreroll.h"

@interface BaiduMobAdPrerollViewController : UIViewController <BaiduMobAdPrerollDelegate>

@end
