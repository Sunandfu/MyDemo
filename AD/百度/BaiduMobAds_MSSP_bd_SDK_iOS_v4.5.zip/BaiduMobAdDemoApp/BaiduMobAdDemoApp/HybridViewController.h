//
//  HybridViewController.h
//  XAdSDKDevSample
//
//  Created by lishan04 on 17/04/2018.
//  Copyright © 2018 Baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HybridViewController : UIViewController

@end
