//
//  NativeLoopViewController.h
//  BaiduMobAdDemoApp
//
//  Created by LiYan on 16/6/6.
//  Copyright © 2016年 Baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NativeLoopViewController : UIViewController
@end
