#import <UIKit/UIKit.h>

@interface NativeVideoTableViewController : UITableViewController

@end
