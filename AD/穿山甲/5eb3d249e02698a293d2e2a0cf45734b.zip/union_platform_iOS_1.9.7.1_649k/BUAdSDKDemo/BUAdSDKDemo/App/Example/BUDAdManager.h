//
//  BUAdManager.h
//  BUDemo
//
//  Created by carlliu on 2017/7/27.
//  Copyright © 2017年 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BUDAdManager : NSObject
+ (NSString *)appKey;
@end
