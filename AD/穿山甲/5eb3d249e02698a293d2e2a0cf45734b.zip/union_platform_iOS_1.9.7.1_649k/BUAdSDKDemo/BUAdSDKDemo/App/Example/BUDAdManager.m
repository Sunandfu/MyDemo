//
//  BUDAdManager.m
//  BUDemo
//
//  Created by carlliu on 2017/7/27.
//  Copyright © 2017年 bytedance. All rights reserved.
//

#import "BUDAdManager.h"

@implementation BUDAdManager

+ (NSString *)appKey {
    return @"5000546";
}

@end
