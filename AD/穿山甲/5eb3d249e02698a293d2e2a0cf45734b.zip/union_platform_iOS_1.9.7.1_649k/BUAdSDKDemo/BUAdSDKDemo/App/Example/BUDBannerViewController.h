//
//  BUDBannerViewController.h
//  BUDemo
//
//  Created by jiacy on 2017/6/6.
//  Copyright © 2017年 bytedance. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BUDBaseExampleViewController.h"

@interface BUDBannerViewController : BUDBaseExampleViewController

@end
