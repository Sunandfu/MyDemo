//
//  BUDDrawVideoViewController.h
//  BUDemo
//
//  Created by 崔亚楠 on 2018/9/20.
//  Copyright © 2018年 bytedance. All rights reserved.
//

#import "BUDBaseExampleViewController.h"

@interface BUDDrawVideoViewController : BUDBaseExampleViewController

@end
