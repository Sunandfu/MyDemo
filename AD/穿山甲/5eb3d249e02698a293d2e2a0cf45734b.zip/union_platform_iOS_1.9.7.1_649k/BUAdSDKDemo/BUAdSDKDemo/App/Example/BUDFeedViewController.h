//
//  BUDFeedViewController.h
//  BUDemo
//
//  Created by chenren on 25/05/2017.
//  Copyright © 2017 bytedance. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BUDBaseExampleViewController.h"

@interface BUDFeedViewController : BUDBaseExampleViewController

@end

