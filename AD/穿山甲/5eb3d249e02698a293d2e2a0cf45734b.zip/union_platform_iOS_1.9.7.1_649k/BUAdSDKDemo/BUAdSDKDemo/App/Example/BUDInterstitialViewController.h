//
//  BUDInterstitialViewController.h
//  BUDemo
//
//  Created by carl on 2017/7/31.
//  Copyright © 2017年 bytedance. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BUDBaseExampleViewController.h"

@interface BUDInterstitialViewController : BUDBaseExampleViewController

@end
