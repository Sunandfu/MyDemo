//
//  BUDNativeViewController.h
//  BUDemo
//
//  Created by carl on 2017/8/15.
//  Copyright © 2017年 bytedance. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BUDBaseExampleViewController.h"

@interface BUDNativeViewController : BUDBaseExampleViewController

@end
