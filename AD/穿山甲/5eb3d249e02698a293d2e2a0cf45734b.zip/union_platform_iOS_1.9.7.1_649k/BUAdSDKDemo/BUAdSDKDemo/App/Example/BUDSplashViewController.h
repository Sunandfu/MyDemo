//
//  BUDSplashViewController.h
//  BUDemo
//
//  Created by carl on 2017/8/7.
//  Copyright © 2017年 bytedance. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BUDBaseExampleViewController.h"

@interface BUDSplashViewController : BUDBaseExampleViewController

@end
