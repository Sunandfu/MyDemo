//
//  BUDViewModel.h
//  BUAdSDKDemo
//
//  Created by carl on 2017/11/10.
//  Copyright © 2017年 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BUDViewModel : NSObject

@end
