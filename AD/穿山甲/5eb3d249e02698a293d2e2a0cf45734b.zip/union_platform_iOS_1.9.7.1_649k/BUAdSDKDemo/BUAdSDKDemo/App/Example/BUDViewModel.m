//
//  BUDViewModel.m
//  BUAdSDKDemo
//
//  Created by carl on 2017/11/10.
//  Copyright © 2017年 bytedance. All rights reserved.
//

#import "BUDViewModel.h"

@implementation BUDViewModel

@end
