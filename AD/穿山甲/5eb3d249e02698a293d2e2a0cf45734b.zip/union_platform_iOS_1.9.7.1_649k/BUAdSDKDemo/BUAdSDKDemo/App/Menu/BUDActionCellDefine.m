//
//  BUDActionCellDefine.m
//  BUAdSDKDemo
//
//  Created by carl on 2017/7/29.
//  Copyright © 2017年 bytedance. All rights reserved.
//

#import "BUDActionCellDefine.h"

@implementation BUDActionModel

@end
