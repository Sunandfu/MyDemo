//
//  AppDelegate.h
//  myChartDemo
//
//  Created by 小富 on 2016/11/9.
//  Copyright © 2016年 yunxiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

