//
//  AppDelegate.h
//  YXScaleDemo
//
//  Created by 小富 on 2017/8/2.
//  Copyright © 2017年 xiaofu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

