//
//  FunctionViewController.h
//  YXBluetoothDemo
//
//  Created by 小富 on 2017/7/31.
//  Copyright © 2017年 xiaofu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SFBLEDeviceInfo.h"

@interface FunctionViewController : UIViewController

@property (nonatomic, strong) SFBLEDeviceInfo *bleInfo;

@end
